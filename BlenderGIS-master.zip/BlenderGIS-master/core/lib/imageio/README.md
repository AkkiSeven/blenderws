This is the Python package that is installed on the user's system.

It consists of a `core` module, which implements the basis of imageio.
The `plugins` module contains the code to actually import/export images,
organised in plugins.

The `freeze` module provides functionality for freezing apps that make 
use of imageio.
